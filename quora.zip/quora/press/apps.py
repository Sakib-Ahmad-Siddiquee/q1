from django.apps import AppConfig


class PressConfig(AppConfig):
    name = 'press'
