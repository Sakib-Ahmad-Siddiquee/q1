from django.apps import AppConfig


class CareersConfig(AppConfig):
    name = 'careers'
