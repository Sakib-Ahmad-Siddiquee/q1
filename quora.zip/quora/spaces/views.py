from django.shortcuts import render

def index(request):
    return render(request, 'spaces/index.html')
