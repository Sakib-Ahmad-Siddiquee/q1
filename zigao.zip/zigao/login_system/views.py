from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required

# Create your views here.

def index(request):
    if request.user.is_authenticated:
        return redirect('/dashboard')
    else:
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')

            user = authenticate(request, password=password, username=username)

            if user is not None:
                login(request, user)
                return redirect('/dashboard')
            else:
                messages.info(request, 'Wrong Credentials')
                
        context = {}
        return render(request, 'login_system/login.html', context)

@login_required(login_url='/')
def logoutUser(request):
    logout(request)
    return redirect('/')    

def register(request):
    if request.user.is_authenticated:
        return redirect('/dashboard')
    else:
        form = UserCreationForm()

        if request.method == 'POST':
            form = UserCreationForm(request.POST)
            if form.is_valid():
                form.save()
                messages.success(request, 'Account Created')
                return redirect('/')

        context = {'form':form}
        return render(request, 'login_system/register.html', context)

@login_required(login_url='/')
def dashboard(request):
    if request.user.is_authenticated:
        return render(request, 'login_system/dashboard.html')
    else:
        return render(request, 'login_system/dashboard.html')  